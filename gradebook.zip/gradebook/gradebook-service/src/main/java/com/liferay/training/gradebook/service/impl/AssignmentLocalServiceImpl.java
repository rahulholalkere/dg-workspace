/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.gradebook.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.dao.orm.Disjunction;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Group;
import com.liferay.portal.kernel.model.ResourceConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.base.AssignmentLocalServiceBaseImpl;
import com.liferay.training.gradebook.validator.AssignmentValidator;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author hgrahul
 */
@Component(
	property = "model.class.name=com.liferay.training.gradebook.model.Assignment",
	service = AopService.class
)
public class AssignmentLocalServiceImpl extends AssignmentLocalServiceBaseImpl {
	/**
	 * 
	 * This behavior will get called whenever request for adding a new assignment
	 * 
	 * @param groupId
	 * @param titleMap
	 * @param descriptionMap
	 * @param dueDate
	 * @param serviceContext
	 * 
	 * @return
	 * @throws PortalException
	 */
	public Assignment addAssignment(long groupId, Map<Locale, String> titleMap, Map<Locale, String> descriptionMap, Date dueDate, ServiceContext serviceContext) throws PortalException {
		// Validate Assignment Fields Values
		assignmentValidator.validate(titleMap, descriptionMap, dueDate);
		
		// Get All Group Or Site Information and Also User Information
		Group currentGroup = groupLocalService.getGroup(groupId);
		
		long currentUserId = serviceContext.getUserId();
		User currentUser = userLocalService.getUser(currentUserId);
		
		// Generate A Primary Key For The Assignment
		long assignmentId = counterLocalService.increment(Assignment.class.getName());
		
		// Using The Primary Key Will Create A New Assignment
		Assignment newAssignment = createAssignment(assignmentId);
		
		// Now Populate Assignment Actual Information To The Assignment Instance
		newAssignment.setTitleMap(titleMap);
		newAssignment.setDescriptionMap(descriptionMap);
		newAssignment.setDueDate(dueDate);
		
		// Now Populate Group and Portal (Company) Details To The Assignment Instance
		newAssignment.setGroupId(groupId);
		newAssignment.setCompanyId(currentGroup.getCompanyId());

		// Now Populate User Information and Creation and Modification Date
		newAssignment.setUserId(currentUserId);
		newAssignment.setUserName(currentUser.getScreenName());
		newAssignment.setCreateDate(serviceContext.getCreateDate(new Date()));
		newAssignment.setModifiedDate(serviceContext.getModifiedDate(new Date()));
		
		newAssignment = super.addAssignment(newAssignment);
		
		// For Adding A Permissioned Resource Details
		boolean portletActions = false;			// We Are Adding Portlet Permission Through gradebook-web modules
		boolean addGroupPermissions = true;		// We Stating To Add Website General Permission To The Service modules
		boolean addGuestPermissions = true;		// We Stating To Add Guest Permission To The Service modules
		
		
		// The Actual Call For Making A Permissioned Resource With Group, Guest And Portlet Details
		resourceLocalService.addResources(currentGroup.getCompanyId(), groupId, currentUserId, Assignment.class.getName(), newAssignment.getAssignmentId(), portletActions, addGroupPermissions, addGuestPermissions);
		
		// Update Asset Information
		updateAsset(newAssignment, serviceContext);
		
		// Now Persist and Return In
		return newAssignment;
	}
	
	public Assignment deleteAssignment(Assignment assignment) throws PortalException {
		// Delete The Permissioned Resource
		resourceLocalService.deleteResource(assignment, ResourceConstants.SCOPE_INDIVIDUAL);
		
		// Delete The Assignment Asset Entry
		assetEntryLocalService.deleteEntry(Assignment.class.getName(), assignment.getAssignmentId());
		
		// Delete The Actual Assignment Aswell
		return super.deleteAssignment(assignment);
	}
	
	/**
	 * 
	 * This behavior will get called whenever request for update an assignment
	 * 
	 * @param assignmentId
	 * @param titleMap
	 * @param descriptionMap
	 * @param dueDate
	 * @param serviceContext
	 * 
	 * @return
	 * @throws PortalException
	 */
	public Assignment updateAssignment(long assignmentId, Map<Locale, String> titleMap, Map<Locale, String> descriptionMap, Date dueDate, ServiceContext serviceContext) throws PortalException {
		// Validate Assignment Fields Values
		assignmentValidator.validate(titleMap, descriptionMap, dueDate);
		
		// Get The Actual Assignment From The AssignmentId
		Assignment modifyAssignment = getAssignment(assignmentId);
		
		// Now Populate New Assignment Information To The Retrieved Assignment Instance
		modifyAssignment.setTitleMap(titleMap);
		modifyAssignment.setDescriptionMap(descriptionMap);
		modifyAssignment.setDueDate(dueDate);
		
		// Update The Modification Date
		modifyAssignment.setModifiedDate(new Date());
		
		// Update Asset Information
		updateAsset(modifyAssignment, serviceContext);
		
		// Persist and Return It
		return super.updateAssignment(modifyAssignment);
	}
	
	public List<Assignment> getAssignmentsByGroupId(long groupId) {
		// This is provided by the finder which we defined in the service.xml
		return assignmentPersistence.findByGroupId(groupId);
	}
	
	public List<Assignment> getAssignmentsByGroupId(long groupId, int start, int end) {
		// This is provided by the finder which we defined in the service.xml
		return assignmentPersistence.findByGroupId(groupId, start, end);
	}
	
	public List<Assignment> getAssignmentsByGroupId(long groupId, int start, int end, OrderByComparator<Assignment> orderByComparator) {
		// This is provided by the finder which we defined in the service.xml
		return assignmentPersistence.findByGroupId(groupId, start, end, orderByComparator);
	}
	
	public DynamicQuery getKeywordSearchDynamicQuery(long groupId, String keywords) {
		// We are adding a restriciton to the dynamicquery that where the search needs to be done.
		DynamicQuery dynamicQuery = dynamicQuery().add(RestrictionsFactoryUtil.eq("groupId", groupId));
		
		if(Validator.isNotNull(keywords)) {
			Disjunction disjunctionQuery = RestrictionsFactoryUtil.disjunction();
			
			// Adding the Restriction To Search Keywords As Like Operation In Both Columns Title and Description
			disjunctionQuery.add(RestrictionsFactoryUtil.like("title", "%" + keywords + "%"));
			disjunctionQuery.add(RestrictionsFactoryUtil.like("description", "%" + keywords + "%"));
			
			// Adding The Restriction To The Dynamic Quest
			dynamicQuery.add(disjunctionQuery);
		}
		
		return dynamicQuery;
	}
	
	public long getAssignmentsCountByKeywords(long groupId, String keywords) {
		return assignmentLocalService.dynamicQueryCount(getKeywordSearchDynamicQuery(groupId, keywords));
	}
	
	public List<Assignment> getAssignmentsByKeywords(long groupId, String keywords, int start, int end, OrderByComparator<Assignment> orderByComparator) {
		return assignmentLocalService.dynamicQuery(getKeywordSearchDynamicQuery(groupId, keywords), start, end, orderByComparator);
	}
	
	/**
	 * Updating Assignment Information To The Asset Hierarchy
	 */
	private void updateAsset(Assignment assignment, ServiceContext serviceContext) throws PortalException {
		assetEntryLocalService.updateEntry(serviceContext.getUserId(), assignment.getGroupId(), assignment.getCreateDate(), assignment.getModifiedDate(), Assignment.class.getName(), assignment.getAssignmentId(), assignment.getUuid(), 0, serviceContext.getAssetCategoryIds(), serviceContext.getAssetTagNames(), true, true, assignment.getCreateDate(), null, null, null, ContentTypes.TEXT_HTML, assignment.getTitle(serviceContext.getLocale()), assignment.getDescription(serviceContext.getLocale()), null, null, null, 0, 0, serviceContext.getAssetPriority());
	}
	
	/**
	 * Silence Those Direct Calls : So That They Cannot Be Overriden In Any Further Levels
	 */
	@Override
	public Assignment addAssignment(Assignment assignment) {
		throw new UnsupportedOperationException("Not Supported Anymore....");
	}
	
	@Override
	public Assignment updateAssignment(Assignment assignment) {
		throw new UnsupportedOperationException("Not Supported Anymore....");
	}
	
	@Reference
	private AssignmentValidator assignmentValidator;
}
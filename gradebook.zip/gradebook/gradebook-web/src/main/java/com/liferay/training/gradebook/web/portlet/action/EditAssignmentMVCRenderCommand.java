package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.exception.NoSuchAssignmentException;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * This class represents an event for rendering an assignment depending on adding or editing purposes.
 * @author hgrahul
 *
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.EDIT_ASSIGNMENT
	},
	service = MVCRenderCommand.class
)
public class EditAssignmentMVCRenderCommand implements MVCRenderCommand{
	@Override
		public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
			// Assuming Rendering Purpose Is For Adding A New Assignment
			Assignment assignment = null;
			
			// Try To Get AssignmentId From Appropriate RenderRequest
			long assignmentId = ParamUtil.getLong(renderRequest, "assignmentId", 0);
			
			try {
				// Check For Assignment Values
				if(assignmentId > 0) {
					// We Understand The Rendering Purpose Is For Editing An Assignment
					assignment = assignmentService.getAssignment(assignmentId);
				}
			}
			catch (NoSuchAssignmentException nsae) {
				nsae.printStackTrace();
			}
			catch (PortalException poe) {
				poe.printStackTrace();
			}
			
			// Want To Also Setup A Back Button To Return From Appropriate Individual Assignment View
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
			
			String redirect = renderRequest.getParameter("redirect");
			
			portletDisplay.setShowBackIcon(true);
			portletDisplay.setURLBack(redirect);
			
			// Setting Up The Individual Assignment To The Request So That It Can Be Rendered
			renderRequest.setAttribute("assignment", assignment);
			renderRequest.setAttribute("assignmentClass", Assignment.class);
			
			// Redirect To Add|Edit View
			return "/assignment/edit_assignment.jsp";
		}
	
	@Reference
	private AssignmentService assignmentService;
}

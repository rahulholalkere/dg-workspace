package com.liferay.training.gradebook.web.portlet;

import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;

import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

/**
 * @author hgrahul
 */
@Component(
	immediate = true,
	property = {
		// This represent the category for the portlet to display
		"com.liferay.portlet.display-category=category.training",
		// CSS Style For Portlet
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		// How To Instanciate On The Page (Multiple Apps On Page Or Not)
		"com.liferay.portlet.instanceable=false",
		// Display Name In The Category
		"javax.portlet.display-name=Gradebook Application",
		// Remove Default Messaging System
		"javax.portlet.init-param.add-process-action-success-action=false",
		// Main Root For All Views
		"javax.portlet.init-param.template-path=/",
		// Main View Component
		"javax.portlet.init-param.view-template=/view.jsp",
		// Internal Portlet Naming In Liferay
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		// Language Convention
		"javax.portlet.resource-bundle=content.Language",
		// General Roles and Permission For The Portlet
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class GradebookPortlet extends MVCPortlet {
}